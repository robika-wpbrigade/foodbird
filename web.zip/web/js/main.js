

$('.slides').slick({
	infinite: true,
	dots:true,
	slidesToShow: 1,
	slidesToScroll: 1,
  
  });
  
  
  
 $(document).ready(function () {

    $('.menu-toggle').click(function () {
   $('.main-sidenav').toggleClass('slider')
    });

});










